require 'test_helper'

class SubscribersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
