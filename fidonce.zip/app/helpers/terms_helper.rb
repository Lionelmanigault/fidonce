module TermsHelper
end
