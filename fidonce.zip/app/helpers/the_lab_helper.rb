module TheLabHelper
end
