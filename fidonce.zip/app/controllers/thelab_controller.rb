class ThelabController < ApplicationController
  def index
  end
end
