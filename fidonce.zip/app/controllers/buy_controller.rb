class BuyController < ApplicationController
  def index
  end
end
