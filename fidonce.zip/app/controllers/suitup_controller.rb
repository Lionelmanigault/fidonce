class SuitupController < ApplicationController
  def index
  end
end
