class TrainersController < ApplicationController
  def index
  end
end
