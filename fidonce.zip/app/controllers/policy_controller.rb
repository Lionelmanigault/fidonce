class PolicyController < ApplicationController
  def index
  end
end
