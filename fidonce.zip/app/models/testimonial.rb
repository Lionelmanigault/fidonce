class Testimonial < ActiveRecord::Base
	
end
