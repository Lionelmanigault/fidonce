class Subscriber < ActiveRecord::Base
end
