class Rail < ActiveRecord::Base
end
